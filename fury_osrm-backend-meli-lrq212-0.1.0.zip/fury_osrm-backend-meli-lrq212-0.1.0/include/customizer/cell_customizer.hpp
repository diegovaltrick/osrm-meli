#ifndef OSRM_CELLS_CUSTOMIZER_HPP
#define OSRM_CELLS_CUSTOMIZER_HPP

#include "partitioner/cell_storage.hpp"
#include "partitioner/multi_level_partition.hpp"
#include "util/query_heap.hpp"

#include <tbb/enumerable_thread_specific.h>
#include <tbb/parallel_for.h>

#include <unordered_set>

namespace osrm
{
namespace customizer
{

class CellCustomizer
{
  private:
    struct HeapData
    {
        bool from_clique;
        EdgeDuration duration;
        EdgeDistance distance;
        //MELI - Adiciona campo para acumular cruzamentos durante etapa de customize
        EdgeCrosses highway_crosses;
        EdgeCrosses avenue_crosses;
        EdgeCrosses other_crosses;
    };

  public:
    using Heap =
        util::QueryHeap<NodeID, NodeID, EdgeWeight, HeapData, util::ArrayStorage<NodeID, int>>;
    using HeapPtr = tbb::enumerable_thread_specific<Heap>;

    CellCustomizer(const partitioner::MultiLevelPartition &partition) : partition(partition) {}

    template <typename GraphT>
    void Customize(const GraphT &graph,
                   Heap &heap,
                   const partitioner::CellStorage &cells,
                   const std::vector<bool> &allowed_nodes,
                   CellMetric &metric,
                   LevelID level,
                   CellID id) const
    {
        auto cell = cells.GetCell(metric, level, id);
        auto destinations = cell.GetDestinationNodes();

        // for each source do forward search
        for (auto source : cell.GetSourceNodes())
        {
            if (!allowed_nodes[source])
            {
                continue;
            }

            std::unordered_set<NodeID> destinations_set;
            for (const auto destination : destinations)
            {
                if (allowed_nodes[destination])
                {
                    destinations_set.insert(destination);
                }
            }
            heap.Clear();
            heap.Insert(source, 0, {false, 0, 0, 0, 0, 0}); //MELI - Inicializa heap com cruzamentos zerados

            // explore search space
            while (!heap.Empty() && !destinations_set.empty())
            {
                const NodeID node = heap.DeleteMin();
                const EdgeWeight weight = heap.GetKey(node);
                const EdgeDuration duration = heap.GetData(node).duration;
                const EdgeDistance distance = heap.GetData(node).distance;
                const EdgeCrosses highway_crosses = heap.GetData(node).highway_crosses;
                const EdgeCrosses avenue_crosses = heap.GetData(node).avenue_crosses;
                const EdgeCrosses other_crosses = heap.GetData(node).other_crosses;

                RelaxNode(graph,
                          cells,
                          allowed_nodes,
                          metric,
                          heap,
                          level,
                          node,
                          weight,
                          duration,
                          distance,
                          highway_crosses,
                          avenue_crosses,
                          other_crosses); //MELI - Repassa par função que irá calcular nó

                destinations_set.erase(node);
            }

            // fill a map of destination nodes to placeholder pointers
            auto weights = cell.GetOutWeight(source);
            auto durations = cell.GetOutDuration(source);
            auto distances = cell.GetOutDistance(source);
            //MELI - Recebe lista de cruzamentos para destinos possíveis
            auto highway_crosses_list = cell.GetOutHighwayCrosses(source);
            auto avenue_crosses_list = cell.GetOutAvenueCrosses(source);
            auto other_crosses_list = cell.GetOutOtherCrosses(source);
            for (auto &destination : destinations)
            {
                BOOST_ASSERT(!weights.empty());
                BOOST_ASSERT(!durations.empty());
                BOOST_ASSERT(!distances.empty());
                BOOST_ASSERT(!highway_crosses_list.empty()); //MELI - Obriga que a lista esteja preenchida
                BOOST_ASSERT(!avenue_crosses_list.empty());
                BOOST_ASSERT(!other_crosses_list.empty());

                const bool inserted = heap.WasInserted(destination);
                weights.front() = inserted ? heap.GetKey(destination) : INVALID_EDGE_WEIGHT;
                durations.front() =
                    inserted ? heap.GetData(destination).duration : MAXIMAL_EDGE_DURATION;
                distances.front() =
                    inserted ? heap.GetData(destination).distance : INVALID_EDGE_DISTANCE;
                //MELI - Se o nó de destino já está no heap, atribui a quantidade de cruzamentos 
                //       já existentes no destino, caso contrário inicializa com zero
                highway_crosses_list.front() = inserted ? heap.GetData(destination).highway_crosses : 0;
                avenue_crosses_list.front() = inserted ? heap.GetData(destination).avenue_crosses : 0;
                other_crosses_list.front() = inserted ? heap.GetData(destination).other_crosses : 0;

                weights.advance_begin(1);
                durations.advance_begin(1);
                distances.advance_begin(1);
                highway_crosses_list.advance_begin(1);
                avenue_crosses_list.advance_begin(1);
                other_crosses_list.advance_begin(1);
            }
            BOOST_ASSERT(weights.empty());
            BOOST_ASSERT(durations.empty());
            BOOST_ASSERT(distances.empty());
            BOOST_ASSERT(highway_crosses_list.empty()); //MELI - Obriga que a lista esteja vazia ao final
            BOOST_ASSERT(avenue_crosses_list.empty());
            BOOST_ASSERT(other_crosses_list.empty());
        }
    }

    template <typename GraphT>
    void Customize(const GraphT &graph,
                   const partitioner::CellStorage &cells,
                   const std::vector<bool> &allowed_nodes,
                   CellMetric &metric) const
    {
        Heap heap_exemplar(graph.GetNumberOfNodes());
        HeapPtr heaps(heap_exemplar);

        for (std::size_t level = 1; level < partition.GetNumberOfLevels(); ++level)
        {
            tbb::parallel_for(tbb::blocked_range<std::size_t>(0, partition.GetNumberOfCells(level)),
                              [&](const tbb::blocked_range<std::size_t> &range) {
                                  auto &heap = heaps.local();
                                  for (auto id = range.begin(), end = range.end(); id != end; ++id)
                                  {
                                      Customize(
                                          graph, heap, cells, allowed_nodes, metric, level, id);
                                  }
                              });
        }
    }

  private:
    template <typename GraphT>
    void RelaxNode(const GraphT &graph,
                   const partitioner::CellStorage &cells,
                   const std::vector<bool> &allowed_nodes,
                   const CellMetric &metric,
                   Heap &heap,
                   LevelID level,
                   NodeID node,
                   EdgeWeight weight,
                   EdgeDuration duration,
                   EdgeDistance distance,
                   EdgeCrosses highway_crosses,
                   EdgeCrosses avenue_crosses,
                   EdgeCrosses other_crosses) const //MELI - Recebe parâmetro na função de cálculo
    {
        auto first_level = level == 1;
        BOOST_ASSERT(heap.WasInserted(node));

        if (!first_level)
        {
            // if we reaches this node from a clique arc we don't need to scan
            // the clique arcs again because of the triangle inequality
            //
            // d(parent, node) + d(node, v) >= d(parent, v)
            //
            // And if there is a path (parent, node, v) there must also be a
            // clique arc (parent, v) with d(parent, v).
            if (!heap.GetData(node).from_clique)
            {
                // Relax sub-cell nodes
                auto subcell_id = partition.GetCell(level - 1, node);
                auto subcell = cells.GetCell(metric, level - 1, subcell_id);
                auto subcell_destination = subcell.GetDestinationNodes().begin();
                auto subcell_duration = subcell.GetOutDuration(node).begin();
                auto subcell_distance = subcell.GetOutDistance(node).begin();
                //MELI - Recebe os cruzamentos quando o caminho já foi calculado
                auto subcell_highway_crosses = subcell.GetOutHighwayCrosses(node).begin();
                auto subcell_avenue_crosses = subcell.GetOutAvenueCrosses(node).begin();
                auto subcell_other_crosses = subcell.GetOutOtherCrosses(node).begin();
                for (auto subcell_weight : subcell.GetOutWeight(node))
                {
                    if (subcell_weight != INVALID_EDGE_WEIGHT)
                    {
                        const NodeID to = *subcell_destination;
                        if (!allowed_nodes[to])
                        {
                            continue;
                        }

                        const EdgeWeight to_weight = weight + subcell_weight;
                        const EdgeDuration to_duration = duration + *subcell_duration;
                        const EdgeDistance to_distance = distance + *subcell_distance;
                        //MELI - Soma cruzamentos recebidos pela função com cruzamentos de caminho já existente
                        const EdgeCrosses to_highway_crosses = highway_crosses + *subcell_highway_crosses;
                        const EdgeCrosses to_avenue_crosses = avenue_crosses + *subcell_avenue_crosses;
                        const EdgeCrosses to_other_crosses = other_crosses + *subcell_other_crosses;
                        if (!heap.WasInserted(to))
                        {
                            heap.Insert(to, to_weight, {true, to_duration, to_distance, to_highway_crosses, to_avenue_crosses, to_other_crosses}); //MELI - Adiciona o nó ao heap
                        }
                        else if (std::tie(to_weight, to_duration, to_distance) <
                                 std::tie(heap.GetKey(to),
                                          heap.GetData(to).duration,
                                          heap.GetData(to).distance))
                        {
                            heap.DecreaseKey(to, to_weight);
                            heap.GetData(to) = {true, to_duration, to_distance, to_highway_crosses, to_avenue_crosses, to_other_crosses}; //MELI - Substitui valores no heap
                        }
                    }

                    ++subcell_destination;
                    ++subcell_duration;
                    ++subcell_distance;
                    ++subcell_highway_crosses;
                    ++subcell_avenue_crosses;
                    ++subcell_other_crosses;
                }
            }
        }

        // Relax base graph edges if a sub-cell border edge
        for (auto edge : graph.GetInternalEdgeRange(level, node))
        {
            const NodeID to = graph.GetTarget(edge);
            if (!allowed_nodes[to])
            {
                continue;
            }

            const auto &data = graph.GetEdgeData(edge);
            if (data.forward && (first_level || partition.GetCell(level - 1, node) !=
                                                    partition.GetCell(level - 1, to)))
            {
                const EdgeWeight to_weight = weight + data.weight;
                const EdgeDuration to_duration = duration + data.duration;
                const EdgeDistance to_distance = distance + data.distance;
                //MELI - Atribui a quantidade de cruzamentos recebida no heap
                EdgeCrosses to_highway_crosses = highway_crosses;
                EdgeCrosses to_avenue_crosses = avenue_crosses;
                EdgeCrosses to_other_crosses = other_crosses;

                if (data.crosstype > 0) { //MELI - Verifica se o turn possui um cruzamento que deve ser contado
                    switch (data.crosstype)
                    {
                        case 1:
                            to_highway_crosses++;
                            break;
                        case 2:
                            to_avenue_crosses++;
                            break;
                        default:
                            to_other_crosses++;
                            break;
                    }
                }

                //MELI - Inclui ou substitui os crosses no heap
                if (!heap.WasInserted(to))
                {
                    heap.Insert(
                        to, to_weight, {false, duration + data.duration, distance + data.distance,
                                        to_highway_crosses, to_avenue_crosses, to_other_crosses});
                }
                else if (std::tie(to_weight, to_duration, to_distance) <
                         std::tie(
                             heap.GetKey(to), heap.GetData(to).duration, heap.GetData(to).distance))
                {
                    heap.DecreaseKey(to, to_weight);
                    heap.GetData(to) = {false, to_duration, to_distance, to_highway_crosses, to_avenue_crosses, to_other_crosses};
                }
            }
        }
    }

    const partitioner::MultiLevelPartition &partition;
};
} // namespace customizer
} // namespace osrm

#endif // OSRM_CELLS_CUSTOMIZER_HPP
