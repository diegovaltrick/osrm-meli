#ifndef OSRM_CONTRACTOR_CONTRACTOR_GRAPH_HPP_
#define OSRM_CONTRACTOR_CONTRACTOR_GRAPH_HPP_

#include "util/dynamic_graph.hpp"
#include "util/turn_info.hpp"
#include "util/score.hpp"
#include <algorithm>

namespace osrm
{
namespace contractor
{

/**
 * MELI - Adicionado contedor de cruzamentos na classe que armazena os edges do contractor
 *
 */
struct ContractorEdgeData
{
    ContractorEdgeData()
        : weight(0), duration(0), distance(0), rail(0), id(0), originalEdges(0), shortcut(0),
          forward(0), backward(0), bridges(0), viaducts(0), tunnels(0), tolls(0),
          turn_info(util::TurnInfo(0, 0, 0, 0, 0, 0)), ferries(0), score(util::Score())
    {
    }
    ContractorEdgeData(EdgeWeight weight,
                       EdgeWeight duration,
                       EdgeDistance distance,
                       EdgeRail rail,
                       unsigned original_edges,
                       unsigned id,
                       bool shortcut,
                       bool forward,
                       bool backward,
                       WayInfo bridges,
                       WayInfo viaducts,
                       WayInfo tunnels,
                       WayInfo tolls,
                       util::TurnInfo turn_info,
                       WayInfo ferries,
                       util::Score score)
        : weight(weight), duration(duration), distance(distance), rail(rail), id(id),
          originalEdges(std::min((1u << 29) - 1u, original_edges)), shortcut(shortcut),
          forward(forward), backward(backward), bridges(bridges),
          viaducts(viaducts), tunnels(tunnels), tolls(tolls), turn_info(turn_info), ferries(ferries),
          score(score)
    {
    }
    EdgeWeight weight;
    EdgeWeight duration;
    EdgeDistance distance;
    EdgeRail rail;
    unsigned id;
    unsigned originalEdges : 29;
    bool shortcut : 1;
    bool forward : 1;
    bool backward : 1;
    WayInfo bridges;
    WayInfo viaducts;
    WayInfo tunnels;
    WayInfo tolls;
    util::TurnInfo turn_info;
    WayInfo ferries;
    util::Score score;
};

using ContractorGraph = util::DynamicGraph<ContractorEdgeData>;
using ContractorEdge = ContractorGraph::InputEdge;

} // namespace contractor
} // namespace osrm

#endif // OSRM_CONTRACTOR_CONTRACTOR_GRAPH_HPP_
