#ifndef SCORE_HPP
#define SCORE_HPP

#include <cstdint>

namespace osrm
{
namespace util
{
struct Score
{
    public:
        Score() : score_sum(0), score_qtd(0) {}
        Score(int score) : score_sum(score), score_qtd(1) {}
        
        void add_score(int score)
        {
            score_sum += score;
            score_qtd++;
        }

        void add_score_obj(Score score)
        {
            score_sum += score.get_score_sum();
            score_qtd += score.get_score_qtd();
        }

        int get_score_sum() const
        {
            return score_sum;
        }

        int get_score_qtd() const
        {
            return score_qtd;
        }

        int get_score() const
        {
            if (score_qtd == 0 || score_sum == 0)
            {
                return 0;
            }

            return score_sum / score_qtd;
        }

    private:
        std::int16_t score_sum;
        std::int16_t score_qtd;
};
} // namespace util
} // namespace osrm

#endif // SCORE_HPP