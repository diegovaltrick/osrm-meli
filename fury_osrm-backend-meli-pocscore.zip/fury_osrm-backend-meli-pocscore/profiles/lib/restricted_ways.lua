Set = require('lib/set')
RestrictedWays = {}

function RestrictedWays.load_restricted_ways()
  local file = "/osrm-profiles/ids.restricted_ways"
  if not RestrictedWays.file_exists(file) then return {} end
  local lines = Set{}
  for line in io.lines(file) do 
    lines[tonumber(line)] = true
  end
  return lines
end

function RestrictedWays.file_exists(file)
    local f = io.open(file, "r")
    if f then f:close() end
    return f ~= nil
end

return RestrictedWays