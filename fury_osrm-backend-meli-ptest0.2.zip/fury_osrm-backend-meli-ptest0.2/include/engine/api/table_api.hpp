#ifndef ENGINE_API_TABLE_HPP
#define ENGINE_API_TABLE_HPP

#include "engine/api/base_api.hpp"
#include "engine/api/base_result.hpp"
#include "engine/api/json_factory.hpp"
#include "engine/api/table_parameters.hpp"

#include "engine/datafacade/datafacade_base.hpp"

#include "engine/guidance/assemble_geometry.hpp"
#include "engine/guidance/assemble_leg.hpp"
#include "engine/guidance/assemble_overview.hpp"
#include "engine/guidance/assemble_route.hpp"
#include "engine/guidance/assemble_steps.hpp"

#include "engine/internal_route_result.hpp"

#include "util/integer_range.hpp"

#include <boost/range/algorithm/transform.hpp>

#include <iterator>

namespace osrm
{
namespace engine
{
namespace api
{

class TableAPI final : public BaseAPI
{
  public:
    struct TableCellRef
    {
        TableCellRef(const std::size_t &row, const std::size_t &column) : row{row}, column{column}
        {
        }
        std::size_t row;
        std::size_t column;
    };

    TableAPI(const datafacade::BaseDataFacade &facade_, const TableParameters &parameters_)
        : BaseAPI(facade_, parameters_), parameters(parameters_)
    {
    }

    //MELI - Alterado o método para ao invés de receber um pair receber uma tupla, que agragar os cruzamentos
    virtual void
    MakeResponse(const std::tuple<std::vector<EdgeDuration>, std::vector<EdgeDistance>,
                    std::vector<EdgeCrosses>, std::vector<EdgeCrosses>, 
                    std::vector<EdgeCrosses>, std::vector<EdgeRail>,
                    std::vector<WayInfo>, std::vector<WayInfo>, std::vector<WayInfo>, 
                    std::vector<WayInfo>, std::vector<TurnCount>, std::vector<TurnCount>> &tables,
                 const std::vector<PhantomNode> &,
                 const std::vector<TableCellRef> &,
                 osrm::engine::api::ResultT &response) const
    {

        auto &json_result = response.get<util::json::Object>();
        MakeResponseMeli(tables, json_result);
    }

    void MakeResponseMeli(const std::tuple<std::vector<EdgeDuration>, std::vector<EdgeDistance>, std::vector<EdgeCrosses>,
                    std::vector<EdgeCrosses>, std::vector<EdgeCrosses>, std::vector<EdgeRail>, std::vector<WayInfo>, std::vector<WayInfo>,
                    std::vector<WayInfo>, std::vector<WayInfo>, 
                    std::vector<TurnCount>, std::vector<TurnCount>> &tables,
                    util::json::Object &response) const
    {
        auto number_of_sources = parameters.sources.size();
        auto number_of_destinations = parameters.destinations.size();

        auto durations = std::get<0>(tables); 
        auto distances = std::get<1>(tables); 
        auto highways = std::get<2>(tables);
        auto avenues = std::get<3>(tables);
        auto others = std::get<4>(tables); 
        auto rails = std::get<5>(tables);
        auto bridges = std::get<6>(tables); 
        auto viaducts = std::get<7>(tables); 
        auto tunnels = std::get<8>(tables);
        auto tolls = std::get<9>(tables);
        auto enters = std::get<10>(tables); 
        auto exits = std::get<11>(tables);

        util::json::Array elements_table;
        util::json::Array durations_table;
        util::json::Array distances_table;
        auto idx = 0;
        std::size_t row = 0;
        while (row < number_of_sources) {
            util::json::Array json_row_elements;
            util::json::Array json_row_durations;
            util::json::Array json_row_distances;
            std::size_t col = 0;

            while (col < number_of_destinations) {
                auto strElements = std::to_string(highways.at(idx)) + "," + std::to_string(avenues.at(idx)) + "," +
                    std::to_string(others.at(idx)) + "," + std::to_string(rails.at(idx)) + "," +
                    std::to_string(bridges.at(idx))+ "," +
                    std::to_string(viaducts.at(idx))+ "," +
                    std::to_string(tunnels.at(idx))+ "," +
                    std::to_string(tolls.at(idx))+ "," +
                    std::to_string(enters.at(idx))+ "," +
                    std::to_string(exits.at(idx));
                json_row_elements.values.push_back(util::json::Value(strElements));

                //DURATION
                auto duration = durations.at(idx);
                if (duration == MAXIMAL_EDGE_DURATION)
                {
                    json_row_durations.values.push_back(util::json::Value(util::json::Null()));
                } else {
                    // division by 10 because the duration is in deciseconds (10s)
                    json_row_durations.values.push_back(util::json::Value(util::json::Number(duration / 10.)));
                }

                //DISTANCE
                auto distance = distances.at(idx);
                if (distance == INVALID_EDGE_DISTANCE)
                {
                    json_row_distances.values.push_back(util::json::Value(util::json::Null()));
                }
                // round to single decimal place
                json_row_distances.values.push_back(util::json::Value(
                    util::json::Number(std::round(distance * 10) / 10.)));

                col++;
                idx++;
            }
            row++;
            elements_table.values.push_back(std::move(json_row_elements));
            distances_table.values.push_back(std::move(json_row_distances));
            durations_table.values.push_back(std::move(json_row_durations));
        }

        if (parameters.annotations & TableParameters::AnnotationsType::Duration)
        {
            response.values["durations"] = durations_table;
        }

        if (parameters.annotations & TableParameters::AnnotationsType::Distance)
        {
            response.values["distances"] = distances_table;
        }

        if (parameters.annotations & TableParameters::AnnotationsType::Crosses)
        {
            response.values["crosses"] = elements_table;
        }
    }

    //MELI - Alterado o método para ao invés de receber um pair receber uma tupla, que agragar os cruzamentos
    virtual void
    MakeResponse(const std::tuple<std::vector<EdgeDuration>, std::vector<EdgeDistance>, std::vector<EdgeCrosses>,
                    std::vector<EdgeCrosses>, std::vector<EdgeCrosses>, std::vector<EdgeRail>, std::vector<WayInfo>, std::vector<WayInfo>,
                    std::vector<WayInfo>, std::vector<WayInfo>, 
                    std::vector<TurnCount>, std::vector<TurnCount>> &tables,
                 const std::vector<PhantomNode> &phantoms,
                 const std::vector<TableCellRef> &fallback_speed_cells,
                 util::json::Object &response) const
    {
        auto number_of_sources = parameters.sources.size();
        auto number_of_destinations = parameters.destinations.size();

        if (parameters.annotations & TableParameters::AnnotationsType::Waypoint)
        {
            // symmetric case
            if (parameters.sources.empty())
            {
                if (!parameters.skip_waypoints)
                {
                    response.values["sources"] = MakeWaypoints(phantoms);
                }
                number_of_sources = phantoms.size();
            }
            else
            {
                if (!parameters.skip_waypoints)
                {
                    response.values["sources"] = MakeWaypoints(phantoms, parameters.sources);
                }
            }

            if (parameters.destinations.empty())
            {
                if (!parameters.skip_waypoints)
                {
                    response.values["destinations"] = MakeWaypoints(phantoms);
                }
                number_of_destinations = phantoms.size();
            }
            else
            {
                if (!parameters.skip_waypoints)
                {
                    response.values["destinations"] = MakeWaypoints(phantoms, parameters.destinations);
                }
            }
        }

        if (parameters.annotations & TableParameters::AnnotationsType::Duration)
        {
            response.values["durations"] =
                MakeDurationTable(std::get<0>(tables), number_of_sources, number_of_destinations);
        }

        if (parameters.annotations & TableParameters::AnnotationsType::Distance)
        {
            response.values["distances"] =
                MakeDistanceTable(std::get<1>(tables), number_of_sources, number_of_destinations);
        }

        if (parameters.annotations & TableParameters::AnnotationsType::Crosses)
        {
            response.values["crosses"] =
                    MakeCrossesTable(std::get<2>(tables), std::get<3>(tables), std::get<4>(tables), std::get<5>(tables), 
                        std::get<6>(tables), std::get<7>(tables), std::get<8>(tables), std::get<9>(tables),
                        std::get<10>(tables), std::get<11>(tables),
                        number_of_sources, number_of_destinations);
        }

        if (parameters.fallback_speed != INVALID_FALLBACK_SPEED && parameters.fallback_speed > 0)
        {
            response.values["fallback_speed_cells"] = MakeEstimatesTable(fallback_speed_cells);
        }

        response.values["code"] = "Ok";
    }

  protected:
    virtual flatbuffers::Offset<flatbuffers::Vector<flatbuffers::Offset<fbresult::Waypoint>>>
    MakeWaypoints(flatbuffers::FlatBufferBuilder &builder,
                  const std::vector<PhantomNode> &phantoms) const
    {
        std::vector<flatbuffers::Offset<fbresult::Waypoint>> waypoints;
        waypoints.reserve(phantoms.size());
        BOOST_ASSERT(phantoms.size() == parameters.coordinates.size());

        boost::range::transform(
            phantoms, std::back_inserter(waypoints), [this, &builder](const PhantomNode &phantom) {
                return BaseAPI::MakeWaypoint(&builder, phantom)->Finish();
            });
        return builder.CreateVector(waypoints);
    }

    virtual flatbuffers::Offset<flatbuffers::Vector<flatbuffers::Offset<fbresult::Waypoint>>>
    MakeWaypoints(flatbuffers::FlatBufferBuilder &builder,
                  const std::vector<PhantomNode> &phantoms,
                  const std::vector<std::size_t> &indices) const
    {
        std::vector<flatbuffers::Offset<fbresult::Waypoint>> waypoints;
        waypoints.reserve(indices.size());
        boost::range::transform(indices,
                                std::back_inserter(waypoints),
                                [this, &builder, phantoms](const std::size_t idx) {
                                    BOOST_ASSERT(idx < phantoms.size());
                                    return BaseAPI::MakeWaypoint(&builder, phantoms[idx])->Finish();
                                });
        return builder.CreateVector(waypoints);
    }

    virtual flatbuffers::Offset<flatbuffers::Vector<float>>
    MakeDurationTable(flatbuffers::FlatBufferBuilder &builder,
                      const std::vector<EdgeWeight> &values) const
    {
        std::vector<float> distance_table;
        distance_table.resize(values.size());
        std::transform(
            values.begin(), values.end(), distance_table.begin(), [](const EdgeWeight duration) {
                if (duration == MAXIMAL_EDGE_DURATION)
                {
                    return 0.;
                }
                return duration / 10.;
            });
        return builder.CreateVector(distance_table);
    }

    virtual flatbuffers::Offset<flatbuffers::Vector<float>>
    MakeDistanceTable(flatbuffers::FlatBufferBuilder &builder,
                      const std::vector<EdgeDistance> &values) const
    {
        std::vector<float> duration_table;
        duration_table.resize(values.size());
        std::transform(
            values.begin(), values.end(), duration_table.begin(), [](const EdgeDistance distance) {
                if (distance == INVALID_EDGE_DISTANCE)
                {
                    return 0.;
                }
                return std::round(distance * 10) / 10.;
            });
        return builder.CreateVector(duration_table);
    }

    virtual flatbuffers::Offset<flatbuffers::Vector<uint32_t>>
    MakeEstimatesTable(flatbuffers::FlatBufferBuilder &builder,
                       const std::vector<TableCellRef> &fallback_speed_cells) const
    {
        std::vector<uint32_t> fb_table;
        fb_table.reserve(fallback_speed_cells.size());
        std::for_each(
            fallback_speed_cells.begin(), fallback_speed_cells.end(), [&](const auto &cell) {
                fb_table.push_back(cell.row);
                fb_table.push_back(cell.column);
            });
        return builder.CreateVector(fb_table);
    }

    virtual util::json::Array MakeWaypoints(const std::vector<PhantomNode> &phantoms) const
    {
        util::json::Array json_waypoints;
        json_waypoints.values.reserve(phantoms.size());
        BOOST_ASSERT(phantoms.size() == parameters.coordinates.size());

        boost::range::transform(
            phantoms,
            std::back_inserter(json_waypoints.values),
            [this](const PhantomNode &phantom) { return BaseAPI::MakeWaypoint(phantom); });
        return json_waypoints;
    }

    virtual util::json::Array MakeWaypoints(const std::vector<PhantomNode> &phantoms,
                                            const std::vector<std::size_t> &indices) const
    {
        util::json::Array json_waypoints;
        json_waypoints.values.reserve(indices.size());
        boost::range::transform(indices,
                                std::back_inserter(json_waypoints.values),
                                [this, phantoms](const std::size_t idx) {
                                    BOOST_ASSERT(idx < phantoms.size());
                                    return BaseAPI::MakeWaypoint(phantoms[idx]);
                                });
        return json_waypoints;
    }

    /**
     * MELI - Método que cria a matriz de cruzamentos baseado na lista recebida
     */
    virtual util::json::Array MakeCrossesTable(const std::vector<int> &highways,
                                               const std::vector<int> &avenues,
                                               const std::vector<int> &others,
                                               const std::vector<EdgeRail> &rails, 
                                               const std::vector<WayInfo> &bridges,
                                               const std::vector<WayInfo> &viaducts,
                                               const std::vector<WayInfo> &tunnels,
                                               const std::vector<WayInfo> &tolls,
                                               const std::vector<TurnCount> &enters,
                                               const std::vector<TurnCount> &exits,
                                               std::size_t number_of_rows,
                                               std::size_t number_of_columns) const
    {
        util::json::Array json_table;
        auto idx = 0;
        std::size_t row = 0;
        while (row < number_of_rows) {
            util::json::Array json_row;
            std::size_t col = 0;

            while (col < number_of_columns) {
                auto strValues = std::to_string(highways.at(idx)) + "," + std::to_string(avenues.at(idx)) + "," +
                    std::to_string(others.at(idx)) + "," + std::to_string(rails.at(idx)) + "," +
                    std::to_string(bridges.at(idx))+ "," +
                    std::to_string(viaducts.at(idx))+ "," +
                    std::to_string(tunnels.at(idx))+ "," +
                    std::to_string(tolls.at(idx))+ "," +
                    std::to_string(enters.at(idx))+ "," +
                    std::to_string(exits.at(idx));
                json_row.values.push_back(util::json::Value(strValues));
                col++;
                idx++;
            }
            row++;
            
            json_table.values.push_back(std::move(json_row));
        }

        return json_table;
    }

    virtual util::json::Array MakeDurationTable(const std::vector<EdgeWeight> &values,
                                                std::size_t number_of_rows,
                                                std::size_t number_of_columns) const
    {
        util::json::Array json_table;
        for (const auto row : util::irange<std::size_t>(0UL, number_of_rows))
        {
            util::json::Array json_row;
            auto row_begin_iterator = values.begin() + (row * number_of_columns);
            auto row_end_iterator = values.begin() + ((row + 1) * number_of_columns);
            json_row.values.resize(number_of_columns);
            std::transform(row_begin_iterator,
                           row_end_iterator,
                           json_row.values.begin(),
                           [](const EdgeWeight duration) {
                               if (duration == MAXIMAL_EDGE_DURATION)
                               {
                                   return util::json::Value(util::json::Null());
                               }
                               // division by 10 because the duration is in deciseconds (10s)
                               return util::json::Value(util::json::Number(duration / 10.));
                           });
            json_table.values.push_back(std::move(json_row));
        }
        return json_table;
    }

    virtual util::json::Array MakeDistanceTable(const std::vector<EdgeDistance> &values,
                                                std::size_t number_of_rows,
                                                std::size_t number_of_columns) const
    {
        util::json::Array json_table;
        for (const auto row : util::irange<std::size_t>(0UL, number_of_rows))
        {
            util::json::Array json_row;
            auto row_begin_iterator = values.begin() + (row * number_of_columns);
            auto row_end_iterator = values.begin() + ((row + 1) * number_of_columns);
            json_row.values.resize(number_of_columns);
            std::transform(row_begin_iterator,
                           row_end_iterator,
                           json_row.values.begin(),
                           [](const EdgeDistance distance) {
                               if (distance == INVALID_EDGE_DISTANCE)
                               {
                                   return util::json::Value(util::json::Null());
                               }
                               // round to single decimal place
                               return util::json::Value(
                                   util::json::Number(std::round(distance * 10) / 10.));
                           });
            json_table.values.push_back(std::move(json_row));
        }
        return json_table;
    }

    virtual util::json::Array
    MakeEstimatesTable(const std::vector<TableCellRef> &fallback_speed_cells) const
    {
        util::json::Array json_table;
        std::for_each(
            fallback_speed_cells.begin(), fallback_speed_cells.end(), [&](const auto &cell) {
                util::json::Array row;
                row.values.push_back(util::json::Number(cell.row));
                row.values.push_back(util::json::Number(cell.column));
                json_table.values.push_back(std::move(row));
            });
        return json_table;
    }

    const TableParameters &parameters;
};

} // namespace api
} // namespace engine
} // namespace osrm

#endif
