#ifndef EDGE_BASED_EDGE_HPP
#define EDGE_BASED_EDGE_HPP

#include "extractor/travel_mode.hpp"
#include "util/typedefs.hpp"
#include "util/turn_info.hpp"
#include <tuple>

namespace osrm
{
namespace extractor
{

/**
 * MELI - Adicionado crosstype para identificar cruzamentos no edge
 * 
 */
struct EdgeBasedEdge
{
  public:
    struct EdgeData
    {
        EdgeData()
            : turn_id(0), weight(0), distance(0), duration(0), rail(0), crosstype(0), forward(false), backward(false),
            bridges(0), viaducts(0), tunnels(0), tolls(0), turn_info(util::TurnInfo(0, 0))
        {
        }

        EdgeData(const NodeID turn_id,
                 const EdgeWeight weight,
                 const EdgeDistance distance,
                 const EdgeWeight duration,
                 const EdgeRail rail,
                 const int crosstype, //LRQ-186 Adicionado tipo de cruzamento do edge
                 const bool forward,
                 const bool backward,
                 const WayInfo bridges,
                 const WayInfo viaducts,
                 const WayInfo tunnels,
                 const WayInfo tolls,
                 const util::TurnInfo turn_info)
            : turn_id(turn_id), weight(weight), distance(distance), duration(duration), 
              rail(rail), crosstype(crosstype),
              forward(forward), backward(backward), bridges(bridges), viaducts(viaducts),
              tunnels(tunnels), tolls(tolls), turn_info(turn_info)
        {
        }

        NodeID turn_id; // ID of the edge based node (node based edge)
        EdgeWeight weight;
        EdgeDistance distance;
        EdgeWeight duration : 30;
        EdgeRail rail;
        int crosstype;
        std::uint32_t forward : 1;
        std::uint32_t backward : 1;

        WayInfo bridges;
        WayInfo viaducts;
        WayInfo tunnels;
        WayInfo tolls;

        util::TurnInfo turn_info;

        auto is_unidirectional() const { return !forward || !backward; }
    };

    EdgeBasedEdge();
    template <class EdgeT> explicit EdgeBasedEdge(const EdgeT &other);
    EdgeBasedEdge(const NodeID source,
                  const NodeID target,
                  const NodeID edge_id,
                  const EdgeWeight weight,
                  const EdgeWeight duration,
                  const EdgeDistance distance,
                  const EdgeRail rail,
                  const int crosses,
                  const bool forward,
                  const bool backward,
                  const WayInfo bridges,
                  const WayInfo viaducts,
                  const WayInfo tunnels,
                  const WayInfo tolls,
                  const util::TurnInfo turn_info);
    EdgeBasedEdge(const NodeID source, const NodeID target, const EdgeBasedEdge::EdgeData &data);

    bool operator<(const EdgeBasedEdge &other) const;

    NodeID source;
    NodeID target;
    EdgeData data;
};
static_assert(sizeof(extractor::EdgeBasedEdge) == 52,
              "Size of extractor::EdgeBasedEdge type is "
              "bigger than expected. This will influence "
              "memory consumption.");

// Impl.

inline EdgeBasedEdge::EdgeBasedEdge() : source(0), target(0) {}

inline EdgeBasedEdge::EdgeBasedEdge(const NodeID source,
                                    const NodeID target,
                                    const NodeID turn_id,
                                    const EdgeWeight weight,
                                    const EdgeWeight duration,
                                    const EdgeDistance distance,
                                    const EdgeRail rail,
                                    const int crosstype,
                                    const bool forward,
                                    const bool backward,
                                    const WayInfo bridges,
                                    const WayInfo viaducts,
                                    const WayInfo tunnels,
                                    const WayInfo tolls,
                                    const util::TurnInfo turn_info)
    : source(source), target(target), 
    data{turn_id, weight, distance, duration, rail, crosstype, forward, backward, bridges, viaducts, tunnels, tolls, turn_info}
{
}

inline EdgeBasedEdge::EdgeBasedEdge(const NodeID source,
                                    const NodeID target,
                                    const EdgeBasedEdge::EdgeData &data)
    : source(source), target(target), data{data}
{
}

inline bool EdgeBasedEdge::operator<(const EdgeBasedEdge &other) const
{
    const auto unidirectional = data.is_unidirectional();
    const auto other_is_unidirectional = other.data.is_unidirectional();
    // if all items are the same, we want to keep bidirectional edges. due to the `<` operator,
    // preferring 0 (false) over 1 (true), we need to compare the inverse of `bidirectional`
    return std::tie(source, target, data.weight, unidirectional) <
           std::tie(other.source, other.target, other.data.weight, other_is_unidirectional);
}
} // namespace extractor
} // namespace osrm

#endif /* EDGE_BASED_EDGE_HPP */
