#ifndef QUERYEDGE_HPP
#define QUERYEDGE_HPP

#include "util/turn_info.hpp"
#include "util/typedefs.hpp"

#include <tuple>

namespace osrm
{
namespace contractor
{

/**
 * MELI - Adiciona propriedades de cruzamento ao objeto data do edge
 * que será acumulado no grafo
 *
 */
struct QueryEdge
{
    NodeID source;
    NodeID target;
    struct EdgeData
    {
        explicit EdgeData()
            : turn_id(0), shortcut(false), weight(0), duration(0), rail(0), forward(false),
              backward(false), distance(0), bridges(0), viaducts(0), tunnels(0), tolls(0),
              turn_info(util::TurnInfo(0, 0, 0, 0, 0, 0)), ferries(0)
        {
        }

        EdgeData(const NodeID turn_id,
                 const bool shortcut,
                 const EdgeWeight weight,
                 const EdgeWeight duration,
                 const EdgeDistance distance,
                 const EdgeRail rail,
                 const bool forward,
                 const bool backward,
                 const WayInfo bridges,
                 const WayInfo viaducts,
                 const WayInfo tunnels,
                 const WayInfo tolls,
                 const util::TurnInfo turn_info,
                 const WayInfo ferries)
            : turn_id(turn_id), shortcut(shortcut), weight(weight), duration(duration), rail(rail),
              forward(forward), backward(backward), distance(distance),bridges(bridges), viaducts(viaducts), tunnels(tunnels),
              tolls(tolls), turn_info(turn_info), ferries(ferries)
        {
        }

        template <class OtherT> EdgeData(const OtherT &other)
        {
            weight = other.weight;
            duration = other.duration;
            rail = other.rail;
            shortcut = other.shortcut;
            turn_id = other.id;
            forward = other.forward;
            backward = other.backward;
            distance = other.distance;
            bridges = other.bridges;
            viaducts = other.viaducts;
            tunnels = other.tunnels;
            tolls = other.tolls;
            turn_info = other.turn_info;
            ferries = other.ferries;
        }
        // this ID is either the middle node of the shortcut, or the ID of the edge based node (node
        // based edge) storing the appropriate data. If `shortcut` is set to true, we get the middle
        // node. Otherwise we see the edge based node to access node data.
        NodeID turn_id : 31;
        bool shortcut : 1;
        EdgeWeight weight;
        EdgeWeight duration : 30;
        EdgeRail rail;
        std::uint32_t forward : 1;
        std::uint32_t backward : 1;
        EdgeDistance distance;
        WayInfo bridges;
        WayInfo viaducts;
        WayInfo tunnels;
        WayInfo tolls;
        util::TurnInfo turn_info;
        WayInfo ferries;
    } data;

    QueryEdge() : source(SPECIAL_NODEID), target(SPECIAL_NODEID) {}

    QueryEdge(NodeID source, NodeID target, EdgeData data)
        : source(source), target(target), data(std::move(data))
    {
    }

    bool operator<(const QueryEdge &rhs) const
    {
        return std::tie(source, target) < std::tie(rhs.source, rhs.target);
    }

    bool operator==(const QueryEdge &right) const
    {
        return (source == right.source && target == right.target &&
                data.weight == right.data.weight && data.duration == right.data.duration &&
                data.shortcut == right.data.shortcut && data.forward == right.data.forward &&
                data.backward == right.data.backward && data.turn_id == right.data.turn_id &&
                data.distance == right.data.distance);
    }
};
} // namespace contractor
} // namespace osrm

#endif // QUERYEDGE_HPP
