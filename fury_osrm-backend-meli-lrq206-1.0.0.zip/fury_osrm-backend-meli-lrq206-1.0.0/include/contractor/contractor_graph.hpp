#ifndef OSRM_CONTRACTOR_CONTRACTOR_GRAPH_HPP_
#define OSRM_CONTRACTOR_CONTRACTOR_GRAPH_HPP_

#include "util/dynamic_graph.hpp"
#include <algorithm>

namespace osrm
{
namespace contractor
{

/**
 * MELI - Adicionado contedor de cruzamentos na classe que armazena os edges do contractor
 * 
 */
struct ContractorEdgeData
{
    ContractorEdgeData()
        : weight(0), duration(0), distance(0), id(0), originalEdges(0), shortcut(0), forward(0),
          backward(0), highway_crosses(0), avenue_crosses(0),
          other_crosses(0)
    {
    }
    ContractorEdgeData(EdgeWeight weight,
                       EdgeWeight duration,
                       EdgeDistance distance,
                       unsigned original_edges,
                       unsigned id,
                       bool shortcut,
                       bool forward,
                       bool backward,
                       EdgeCrosses highway_crosses,
                       EdgeCrosses avenue_crosses,
                       EdgeCrosses other_crosses)
        : weight(weight), duration(duration), distance(distance), id(id),
          originalEdges(std::min((1u << 29) - 1u, original_edges)), shortcut(shortcut),
          forward(forward), backward(backward), highway_crosses(highway_crosses), avenue_crosses(avenue_crosses),
          other_crosses(other_crosses)
    {
    }
    EdgeWeight weight;
    EdgeWeight duration;
    EdgeDistance distance;
    unsigned id;
    unsigned originalEdges : 29;
    bool shortcut : 1;
    bool forward : 1;
    bool backward : 1;
    EdgeCrosses highway_crosses;
    EdgeCrosses avenue_crosses;
    EdgeCrosses other_crosses;
};

using ContractorGraph = util::DynamicGraph<ContractorEdgeData>;
using ContractorEdge = ContractorGraph::InputEdge;

} // namespace contractor
} // namespace osrm

#endif // OSRM_CONTRACTOR_CONTRACTOR_GRAPH_HPP_
