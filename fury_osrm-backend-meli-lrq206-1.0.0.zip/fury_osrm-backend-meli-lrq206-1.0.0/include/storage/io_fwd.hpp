#ifndef OSRM_STORAGE_IO_FWD_HPP_
#define OSRM_STORAGE_IO_FWD_HPP_

namespace osrm
{
namespace storage
{
namespace io
{

class FileReader;
class FileWriter;

} // namespace io
} // namespace storage
} // namespace osrm

#endif
