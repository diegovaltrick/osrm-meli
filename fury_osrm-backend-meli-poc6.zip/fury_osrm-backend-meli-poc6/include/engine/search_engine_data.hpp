#ifndef SEARCH_ENGINE_DATA_HPP
#define SEARCH_ENGINE_DATA_HPP

#include "engine/algorithm.hpp"
#include "util/query_heap.hpp"
#include "util/typedefs.hpp"
#include "util/turn_info.hpp"

#include <boost/thread/tss.hpp>

namespace osrm
{
namespace engine
{

// Algorithm-dependent heaps
// - CH algorithms use CH heaps
// - CoreCH algorithms use CH
// - MLD algorithms use MLD heaps

template <typename Algorithm> struct SearchEngineData
{
};

struct HeapData
{
    NodeID parent;
    /* explicit */ HeapData(NodeID p) : parent(p) {}
};

struct ManyToManyHeapData : HeapData
{
    EdgeWeight duration;
    EdgeDistance distance;
    //MELI - Adicionado campo para acumular cruzamentos no edge
    EdgeCrosses highway_crosses;
    EdgeCrosses avenue_crosses;
    EdgeCrosses other_crosses;
    EdgeRail rails;
    WayInfo bridges;
    WayInfo viaducts;
    WayInfo tunnels;
    WayInfo tolls;
    TurnCount enters;
    TurnCount exits;
    ManyToManyHeapData(NodeID p, EdgeWeight duration, EdgeDistance distance, 
        EdgeCrosses highway_crosses, EdgeCrosses avenue_crosses, EdgeCrosses other_crosses, EdgeRail rails,
        WayInfo bridges, WayInfo viaducts, WayInfo tunnels, WayInfo tolls, TurnCount enters, TurnCount exits)
        : HeapData(p), duration(duration), distance(distance), 
            highway_crosses(highway_crosses), avenue_crosses(avenue_crosses), 
            other_crosses(other_crosses), rails(rails),
            bridges(bridges), viaducts(viaducts), tunnels(tunnels), tolls(tolls),
            enters(enters), exits(exits)
    {
    }
};

template <> struct SearchEngineData<routing_algorithms::ch::Algorithm>
{
    using QueryHeap = util::
        QueryHeap<NodeID, NodeID, EdgeWeight, HeapData, util::UnorderedMapStorage<NodeID, int>>;

    using ManyToManyQueryHeap = util::QueryHeap<NodeID,
                                                NodeID,
                                                EdgeWeight,
                                                ManyToManyHeapData,
                                                util::UnorderedMapStorage<NodeID, int>>;

    using SearchEngineHeapPtr = boost::thread_specific_ptr<QueryHeap>;
    using ManyToManyHeapPtr = boost::thread_specific_ptr<ManyToManyQueryHeap>;

    static SearchEngineHeapPtr forward_heap_1;
    static SearchEngineHeapPtr reverse_heap_1;
    static SearchEngineHeapPtr forward_heap_2;
    static SearchEngineHeapPtr reverse_heap_2;
    static SearchEngineHeapPtr forward_heap_3;
    static SearchEngineHeapPtr reverse_heap_3;
    static ManyToManyHeapPtr many_to_many_heap;

    void InitializeOrClearFirstThreadLocalStorage(unsigned number_of_nodes);

    void InitializeOrClearSecondThreadLocalStorage(unsigned number_of_nodes);

    void InitializeOrClearThirdThreadLocalStorage(unsigned number_of_nodes);

    void InitializeOrClearManyToManyThreadLocalStorage(unsigned number_of_nodes);
};

struct MultiLayerDijkstraHeapData
{
    NodeID parent;
    bool from_clique_arc;
    MultiLayerDijkstraHeapData(NodeID p) : parent(p), from_clique_arc(false) {}
    MultiLayerDijkstraHeapData(NodeID p, bool from) : parent(p), from_clique_arc(from) {}
};

struct ManyToManyMultiLayerDijkstraHeapData : MultiLayerDijkstraHeapData
{
    EdgeWeight duration;
    EdgeDistance distance;
    //MELI - Adiciona campo ao heap Dijkstra
    EdgeCrosses highway_crosses;
    EdgeCrosses avenue_crosses;
    EdgeCrosses other_crosses;
    EdgeRail rails;
    WayInfo bridges;
    WayInfo viaducts;
    WayInfo tunnels;
    WayInfo tolls;
    TurnCount enters;
    TurnCount exits;
    ManyToManyMultiLayerDijkstraHeapData(NodeID p, EdgeWeight duration, EdgeDistance distance, EdgeRail rails,
        WayInfo bridges, WayInfo viaducts, WayInfo tunnels, WayInfo tolls, 
        TurnCount enters, TurnCount exits)
        : MultiLayerDijkstraHeapData(p), duration(duration), distance(distance), highway_crosses(0), avenue_crosses(0), other_crosses(0), rails(rails),
            bridges(bridges), viaducts(viaducts), tunnels(tunnels), tolls(tolls), 
            enters(enters), exits(exits)
    {
    }
    ManyToManyMultiLayerDijkstraHeapData(NodeID p,
                                         bool from,
                                         EdgeWeight duration,
                                         EdgeDistance distance,
                                         EdgeRail rails,
                                         WayInfo bridges, 
                                         WayInfo viaducts, 
                                         WayInfo tunnels, 
                                         WayInfo tolls)
        : MultiLayerDijkstraHeapData(p, from), duration(duration), distance(distance), highway_crosses(0), avenue_crosses(0), other_crosses(0), rails(rails),
            bridges(bridges), viaducts(viaducts), tunnels(tunnels), tolls(tolls), 
            enters(0), exits(0)
    {
    }
    ManyToManyMultiLayerDijkstraHeapData(NodeID p, EdgeWeight duration, EdgeDistance distance,
                                        EdgeCrosses highway_crosses, EdgeCrosses avenue_crosses, EdgeCrosses other_crosses, EdgeRail rails,
                                        WayInfo bridges, WayInfo viaducts, WayInfo tunnels, WayInfo tolls, 
                                        TurnCount enters, TurnCount exits)
        : MultiLayerDijkstraHeapData(p), duration(duration), distance(distance),
        highway_crosses(highway_crosses), avenue_crosses(avenue_crosses), other_crosses(other_crosses), rails(rails),
        bridges(bridges), viaducts(viaducts), tunnels(tunnels), tolls(tolls), 
        enters(enters), exits(exits)
    {
    }
    ManyToManyMultiLayerDijkstraHeapData(NodeID p,
                                         bool from,
                                         EdgeWeight duration,
                                         EdgeDistance distance,
                                         EdgeCrosses highway_crosses,
                                         EdgeCrosses avenue_crosses,
                                         EdgeCrosses other_crosses,
                                         EdgeRail rails,
                                         WayInfo bridges, 
                                         WayInfo viaducts, 
                                         WayInfo tunnels, 
                                         WayInfo tolls,
                                         TurnCount enters,
                                         TurnCount exits)
        : MultiLayerDijkstraHeapData(p, from), duration(duration), distance(distance),
            highway_crosses(highway_crosses), avenue_crosses(avenue_crosses), other_crosses(other_crosses),
            rails(rails),
            bridges(bridges), viaducts(viaducts), tunnels(tunnels), tolls(tolls),
            enters(enters), exits(exits)
    {
    }
};

template <> struct SearchEngineData<routing_algorithms::mld::Algorithm>
{
    using QueryHeap = util::QueryHeap<NodeID,
                                      NodeID,
                                      EdgeWeight,
                                      MultiLayerDijkstraHeapData,
                                      util::TwoLevelStorage<NodeID, int>>;

    using ManyToManyQueryHeap = util::QueryHeap<NodeID,
                                                NodeID,
                                                EdgeWeight,
                                                ManyToManyMultiLayerDijkstraHeapData,
                                                util::TwoLevelStorage<NodeID, int>>;

    using SearchEngineHeapPtr = boost::thread_specific_ptr<QueryHeap>;
    using ManyToManyHeapPtr = boost::thread_specific_ptr<ManyToManyQueryHeap>;

    static SearchEngineHeapPtr forward_heap_1;
    static SearchEngineHeapPtr reverse_heap_1;
    static ManyToManyHeapPtr many_to_many_heap;

    void InitializeOrClearFirstThreadLocalStorage(unsigned number_of_nodes,
                                                  unsigned number_of_boundary_nodes);

    void InitializeOrClearManyToManyThreadLocalStorage(unsigned number_of_nodes,
                                                       unsigned number_of_boundary_nodes);
};
} // namespace engine
} // namespace osrm

#endif // SEARCH_ENGINE_DATA_HPP
