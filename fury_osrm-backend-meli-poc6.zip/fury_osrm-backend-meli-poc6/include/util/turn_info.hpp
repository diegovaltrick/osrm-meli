#ifndef TURN_INFO_HPP
#define TURN_INFO_HPP

namespace osrm
{
namespace util
{
    struct TurnInfo
    {
        public:
            TurnInfo() : enters(0), exits(0) {}
            TurnInfo(int enters, int exits) : enters(enters), exits(exits) {}
            
        int enters;
        int exits;
    };  
}}

#endif // TURN_INFO_HPP